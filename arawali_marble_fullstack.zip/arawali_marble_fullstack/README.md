# Arawali Marble — full-stack storefront starter

This is a responsive Flipkart-inspired storefront demo with a small Node.js backend:
- Product catalogue API (`GET /api/products`)
- Cart saved in the customer's browser
- Delivery address and optional browser GPS coordinates
- Order submission and persistent order records (`POST /api/orders`)
- Admin order dashboard (`/admin.html`) to review orders and update status
- JSON-file persistence at `data/orders.json`

## Run locally
1. Install Node.js 18 or newer.
2. Extract the ZIP and open a terminal in this folder.
3. Run `npm install`.
4. Set an admin secret before launch:
   - Linux/macOS: `ADMIN_KEY='use-a-long-random-secret-here' npm start`
   - Windows PowerShell: `$env:ADMIN_KEY='use-a-long-random-secret-here'; npm start`
5. Open `http://localhost:3000`.

For local GPS, use localhost. On a deployed site, browser geolocation requires HTTPS and customer permission.

## Important before real customers
- Sample catalogue names and rates are illustrative. Replace with your real products, SKU, images, stock, measurement units, tax treatment and verified rates.
- The backend saves order enquiries, but does not collect online payment or automatically calculate transport/GST. Confirm those with the customer.
- This starter uses a JSON file for easy testing. For production/multiple staff, migrate to PostgreSQL/MySQL, add proper admin login/session security, HTTPS, rate limiting, backups, audit logs, and privacy/retention policies.
- Do not use the demo admin key. Set a strong secret in the server environment; do not put it in public frontend code.
- GPS coordinates are optional and only captured after the customer clicks the GPS button and grants browser permission. The written address remains required.
- Admin endpoint is protected by `x-admin-key`, but this is a starter implementation, not a substitute for a production identity system.
