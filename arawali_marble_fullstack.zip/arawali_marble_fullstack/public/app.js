const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
let products = [], cart = loadCart(), activeFilter = 'all', gps = null, toastTimer;
function loadCart(){try{return JSON.parse(localStorage.getItem('arawali-cart')||'{}')}catch{return {}}}
function saveCart(){localStorage.setItem('arawali-cart',JSON.stringify(cart));updateCartCount()}
function money(n){return new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR',maximumFractionDigits:0}).format(n)}
function note(msg){let t=$('#toast');t.textContent=msg;t.classList.remove('hidden');t.style.display='block';clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.style.display='none',2600)}
function safe(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function artClass(p){return ({white:'white-stone',black:'black-stone',grey:'',beige:'beige-stone',green:'green-stone',cream:'white-stone'})[p.color]||'white-stone'}
function renderProducts(){
 const q=$('#query').value.trim().toLowerCase();
 const shown=products.filter(p=>(activeFilter==='all'||p.category===activeFilter)&&(!q||(p.name+' '+p.category+' '+p.description).toLowerCase().includes(q)));
 $('#productGrid').innerHTML=shown.map(p=>`<article class="product-card" data-product="${safe(p.id)}"><div class="product-image"><div class="stone-img ${artClass(p)}"></div>${p.color==='white'||p.color==='cream'?'<div class="mini-slab"></div>':''}</div><div class="product-name">${safe(p.name)}</div><span class="rating">4.4 ★</span><div class="price"><span class="old-price">${money(Math.round(p.price*1.22))}</span>${money(p.price)}</div><p class="offer">Indicative rate · ${safe(p.unit||'sq. ft.')}</p><button class="add-btn" data-add="${safe(p.id)}">＋ Add to order</button></article>`).join('');
 $('#emptyState').classList.toggle('hidden',shown.length>0);
 $$('[data-add]').forEach(b=>b.addEventListener('click',e=>{e.stopPropagation();addToCart(b.dataset.add)}));
 $$('.product-card').forEach(card=>card.addEventListener('click',e=>{if(e.target.closest('button'))return;addToCart(card.dataset.product)}));
}
async function fetchProducts(){try{const r=await fetch('/api/products');if(!r.ok)throw Error();const d=await r.json();products=d.products;renderProducts()}catch{$('#productGrid').innerHTML='<div class="loading">Catalogue could not load. Please restart the server and refresh.</div>'}}
function updateCartCount(){const n=Object.values(cart).reduce((a,b)=>a+b,0);$('#cartCount').textContent=n;$('#cartCountBottom').textContent=n}
function addToCart(id){if(!products.some(p=>p.id===id))return;cart[id]=(cart[id]||0)+1;saveCart();note('Added to your order');}
function setFilter(f){activeFilter=f;$$('#categories button').forEach(b=>b.classList.toggle('active',b.dataset.filter===f));renderProducts();$('#products').scrollIntoView({behavior:'smooth'})}
function cartRows(){const entries=Object.entries(cart).filter(([id,q])=>q>0&&products.some(p=>p.id===id));if(!entries.length)return '<div class="empty">Your cart is empty. Add a product to start an order.</div>';return entries.map(([id,q])=>{const p=products.find(x=>x.id===id);return `<div class="cart-line"><div><strong>${safe(p.name)}</strong><small>${money(p.price)} / ${safe(p.unit||'sq. ft.')} · Line total ${money(p.price*q)}</small></div><div class="qty-control"><button data-qty="-1" data-id="${safe(id)}" aria-label="Decrease">−</button><b>${q}</b><button data-qty="1" data-id="${safe(id)}" aria-label="Increase">+</button></div></div>`}).join('')}
function subtotal(){return Object.entries(cart).reduce((sum,[id,q])=>sum+(products.find(p=>p.id===id)?.price||0)*q,0)}
function openCart(){$('#cartItems').innerHTML=cartRows();$('#cartSubtotal').textContent=money(subtotal());$('#cartDialog').showModal();$$('[data-qty]').forEach(b=>b.onclick=()=>{const id=b.dataset.id;cart[id]=(cart[id]||0)+Number(b.dataset.qty);if(cart[id]<=0)delete cart[id];saveCart();openCart()});}
function openCheckout(){if(!Object.values(cart).some(q=>q>0)){note('Please add at least one item first.');return}$('#cartDialog').close();$('#checkoutDialog').showModal()}
function useGPS(){const status=$('#gpsStatus');if(!navigator.geolocation){status.textContent='GPS is not supported by this browser.';return}status.textContent='Requesting location permission…';navigator.geolocation.getCurrentPosition(pos=>{gps={latitude:pos.coords.latitude,longitude:pos.coords.longitude,accuracy:Math.round(pos.coords.accuracy)};status.textContent=`Location captured (±${gps.accuracy} m). Enter your written address too.`;$('#locationLabel').textContent=`GPS saved · ${gps.latitude.toFixed(3)}, ${gps.longitude.toFixed(3)}`;note('GPS coordinates added to this order.')},err=>{status.textContent=err.code===1?'Permission denied. Allow location in browser settings.':'Location unavailable. Try outdoors or enter address manually.'},{enableHighAccuracy:true,timeout:15000,maximumAge:60000})}
async function placeOrder(e){e.preventDefault();if(!Object.values(cart).some(q=>q>0)){note('Your cart is empty.');return}const f=new FormData(e.currentTarget);const payload={customer:{name:f.get('name'),phone:f.get('phone'),email:f.get('email')},address:{line1:f.get('line1'),line2:f.get('line2'),city:f.get('city'),state:f.get('state'),pincode:f.get('pincode'),latitude:gps?.latitude??null,longitude:gps?.longitude??null},deliveryNote:f.get('deliveryNote'),items:Object.entries(cart).filter(([id,q])=>q>0).map(([productId,quantity])=>({productId,quantity}))};const btn=$('#placeOrderBtn');btn.disabled=true;btn.textContent='Sending order…';try{const r=await fetch('/api/orders',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});const d=await r.json();if(!r.ok)throw new Error(d.error||'Order could not be submitted.');$('#successText').textContent=`Your reference number is ${d.order.id}. Subtotal: ${money(d.order.subtotal)}.`;$('#checkoutDialog').close();$('#successDialog').showModal();cart={};gps=null;saveCart();e.currentTarget.reset();$('#locationLabel').textContent='Add your location';$('#gpsStatus').textContent='Optional · browser permission required';}catch(err){note(err.message||'Network error. Please try again.')}finally{btn.disabled=false;btn.textContent='Place order enquiry'}}
$$('[data-scroll]').forEach(b=>b.addEventListener('click',()=>document.getElementById(b.dataset.scroll)?.scrollIntoView({behavior:'smooth'})));
$$('[data-filter]').forEach(b=>b.addEventListener('click',()=>setFilter(b.dataset.filter)));
$$('[data-filter-pick]').forEach(b=>b.addEventListener('click',()=>setFilter(b.dataset.filterPick)));
$$('[data-close]').forEach(b=>b.addEventListener('click',()=>$('#'+b.dataset.close).close()));
$('#searchForm').addEventListener('submit',e=>{e.preventDefault();renderProducts();$('#products').scrollIntoView({behavior:'smooth'})});
$('#query').addEventListener('input',renderProducts);$('#clearSearch').onclick=()=>{$('#query').value='';renderProducts();$('#query').focus()};$('#searchGo').onclick=()=>{renderProducts();$('#products').scrollIntoView({behavior:'smooth'})};
$('#cartTop').onclick=openCart;$('#cartBottom').onclick=openCart;$('#checkoutBtn').onclick=openCheckout;$('#checkoutForm').addEventListener('submit',placeOrder);$('#getLiveLocation').onclick=useGPS;
$('#locationBtn').onclick=()=>{if(!navigator.geolocation){note('GPS is not supported in this browser.');return}useGPS();$('#checkoutDialog').showModal()};
$('#addressBottom').onclick=()=>{$('#checkoutDialog').showModal()};
$('#helpBtn').onclick=()=>note('Store contact number and WhatsApp support can be configured before launch.');
$('#viewAll').onclick=()=>setFilter('all');
updateCartCount();fetchProducts();
