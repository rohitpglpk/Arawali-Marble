const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const ADMIN_KEY = process.env.ADMIN_KEY || '';
const DATA_DIR = path.join(__dirname, 'data');
const ORDERS_FILE = path.join(DATA_DIR, 'orders.json');

app.disable('x-powered-by');
app.use(express.json({ limit: '100kb' }));
app.use(express.static(path.join(__dirname, 'public')));

const products = [
  { id:'marble-white', name:'Classic White Marble', category:'marble', price:899, unit:'sq. ft.', description:'Light, elegant finish for bright interiors.', color:'white', image:'' },
  { id:'granite-black', name:'Midnight Black Granite', category:'granite', price:1150, unit:'sq. ft.', description:'Bold dark stone for kitchens and counters.', color:'black', image:'' },
  { id:'marble-grey', name:'Silver Grey Marble', category:'marble', price:999, unit:'sq. ft.', description:'Modern grey tones with natural variation.', color:'grey', image:'' },
  { id:'tiles-beige', name:'Warm Beige Floor Tiles', category:'tiles', price:69, unit:'sq. ft.', description:'Neutral flooring for contemporary spaces.', color:'beige', image:'' },
  { id:'granite-green', name:'Forest Green Granite', category:'granite', price:1250, unit:'sq. ft.', description:'Natural green stone with distinctive pattern.', color:'green', image:'' },
  { id:'marble-vanity', name:'Vanity Marble Surface', category:'marble', price:850, unit:'sq. ft.', description:'A clean finish for vanity and interior use.', color:'cream', image:'' }
];

function ensureStore() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(ORDERS_FILE)) fs.writeFileSync(ORDERS_FILE, '[]\n');
}
function readOrders() {
  ensureStore();
  try { return JSON.parse(fs.readFileSync(ORDERS_FILE, 'utf8')); }
  catch { throw new Error('Order storage could not be read.'); }
}
function writeOrders(orders) {
  ensureStore();
  const temp = ORDERS_FILE + '.tmp';
  fs.writeFileSync(temp, JSON.stringify(orders, null, 2));
  fs.renameSync(temp, ORDERS_FILE);
}
function adminOnly(req, res, next) {
  if (!ADMIN_KEY || ADMIN_KEY === 'change-this-to-a-long-random-secret') {
    return res.status(503).json({ error: 'Admin is not configured. Set a strong ADMIN_KEY environment variable first.' });
  }
  const supplied = req.get('x-admin-key') || '';
  const a = Buffer.from(supplied);
  const b = Buffer.from(ADMIN_KEY);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return res.status(401).json({ error: 'Invalid admin key.' });
  }
  next();
}
app.get('/api/health', (req, res) => res.json({ ok:true, service:'Arawali Marble API' }));
app.get('/api/products', (req, res) => res.json({ products, note:'Sample catalogue. Replace with verified stock, images and prices before launch.' }));

app.post('/api/orders', (req, res) => {
  const body = req.body || {};
  const customer = body.customer || {};
  const address = body.address || {};
  const items = Array.isArray(body.items) ? body.items : [];
  if (!String(customer.name || '').trim() || !String(customer.phone || '').trim()) {
    return res.status(400).json({ error:'Customer name and phone are required.' });
  }
  if (!String(address.line1 || '').trim() || !String(address.city || '').trim() || !String(address.state || '').trim() || !String(address.pincode || '').trim()) {
    return res.status(400).json({ error:'Complete delivery address and PIN code are required.' });
  }
  if (!/^[0-9+\-\s()]{8,18}$/.test(String(customer.phone).trim())) {
    return res.status(400).json({ error:'Enter a valid phone number.' });
  }
  if (!/^\d{6}$/.test(String(address.pincode).trim())) {
    return res.status(400).json({ error:'PIN code must contain 6 digits.' });
  }
  if (!items.length || items.length > 50) return res.status(400).json({ error:'Add between 1 and 50 items.' });

  const normalized = [];
  for (const item of items) {
    const product = products.find(p => p.id === item.productId);
    const qty = Number(item.quantity);
    if (!product || !Number.isInteger(qty) || qty < 1 || qty > 10000) {
      return res.status(400).json({ error:'An item or quantity is invalid.' });
    }
    normalized.push({ productId:product.id, name:product.name, unit:product.unit, unitPrice:product.price, quantity:qty, lineTotal:product.price * qty });
  }
  const subtotal = normalized.reduce((sum, item) => sum + item.lineTotal, 0);
  const order = {
    id:'AM-' + Date.now().toString(36).toUpperCase() + '-' + crypto.randomBytes(2).toString('hex').toUpperCase(),
    createdAt:new Date().toISOString(),
    status:'Received',
    paymentStatus:'Pay on confirmation',
    customer:{ name:String(customer.name).trim(), phone:String(customer.phone).trim(), email:String(customer.email || '').trim() },
    address:{
      line1:String(address.line1).trim(), line2:String(address.line2 || '').trim(),
      landmark:String(address.landmark || '').trim(), city:String(address.city).trim(),
      state:String(address.state).trim(), pincode:String(address.pincode).trim(),
      latitude:Number.isFinite(Number(address.latitude)) ? Number(address.latitude) : null,
      longitude:Number.isFinite(Number(address.longitude)) ? Number(address.longitude) : null
    },
    items:normalized, subtotal, deliveryNote:String(body.deliveryNote || '').trim(),
    note:'Demo checkout: confirm stock, freight, final stone measurements and payment with the customer.'
  };
  const orders = readOrders();
  orders.unshift(order);
  writeOrders(orders);
  res.status(201).json({ message:'Order received. The store team should confirm price, availability and delivery.', order });
});

app.get('/api/admin/orders', adminOnly, (req, res) => {
  const orders = readOrders();
  res.json({ total:orders.length, orders });
});
app.patch('/api/admin/orders/:id/status', adminOnly, (req, res) => {
  const allowed = ['Received','Confirmed','Preparing','Dispatched','Delivered','Cancelled'];
  const status = String((req.body || {}).status || '');
  if (!allowed.includes(status)) return res.status(400).json({ error:'Unsupported order status.' });
  const orders = readOrders();
  const order = orders.find(o => o.id === req.params.id);
  if (!order) return res.status(404).json({ error:'Order not found.' });
  order.status = status;
  order.updatedAt = new Date().toISOString();
  writeOrders(orders);
  res.json({ order });
});

app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.listen(PORT, () => {
  ensureStore();
  console.log(`Arawali Marble running at http://localhost:${PORT}`);
});
